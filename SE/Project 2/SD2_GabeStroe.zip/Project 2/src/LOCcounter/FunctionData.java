package LOCcounter;

/**
 * Public case to store the function data. From Project 2 assignment.
 */
public class FunctionData
{
    public String functionName = null;
    public int functionLOC = 0;

    public FunctionData() {

    }


}