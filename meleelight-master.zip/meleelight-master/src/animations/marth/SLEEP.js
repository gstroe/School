module.exports = [[new Int16Array([0,1,0,1,1,1,1,1])]]
