import UPSPECIALCHARGE from "./UPSPECIALCHARGE";

export default {
  name : "UPSPECIAL",
  init : function(p){
    UPSPECIALCHARGE.init(p);
  }
};
