11/2/2006

In this directory, store project related documents such as project proposals, plans and schedules, team meeting minutes, requirement specification, design notes, hardware data sheets, manuals, user's guides, etc.

Partition the information in subdirectories as appropriate, perhaps partitioned by Project Management vs. technical specifications.

~Ben Sweet
