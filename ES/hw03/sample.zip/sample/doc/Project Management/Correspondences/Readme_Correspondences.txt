11/2/2006

Use this folder to keep copies of important e-mails related to the project.  

It may be helpful to add the date to the filename.  Using a filename like "20061102_..." will allow the files to be easily arranged by date.


~Ben Sweet