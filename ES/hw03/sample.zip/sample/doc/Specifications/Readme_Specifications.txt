11/2/2006

Use this folder to store project specifications such as Requirements, Designs, Test Plans & Results, etc.

Partition the information in directories as appropriate to facilitate understanding without adding unnecessary complexity.

~Ben Sweet
