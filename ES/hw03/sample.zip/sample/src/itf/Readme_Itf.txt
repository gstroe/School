Created:  05/04/2012
Modified: 05/04/2012

The "Interface" componets are abstractions of Input and Output Interface devices, sensors, etc.  It is presumed that these Interfaces will directly interact with microcontroller-specific drivers.

Some possible common interfaces might be:
- Kpd - alpha-numeric keypad
- LCD - Liquid Crystal Display 
- SevenSeg - Seven Segment Display


~Ben Sweet
