Created:   6/4/2008
Modified:  6/4/2008

Drivers related to Non-Volatile Memory (NVM):
* FLASH
* EEPROM


~Ben Sweet