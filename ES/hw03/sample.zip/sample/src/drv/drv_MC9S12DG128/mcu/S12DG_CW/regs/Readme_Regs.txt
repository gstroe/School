Created: 11/2/2006


Use this folder to store drivers related to the microcontroller configuration that is not handled in other drivers.
This may include:
* Unused I/O ports
* Unused Interrupt Vectors 
* etc.


~Ben Sweet