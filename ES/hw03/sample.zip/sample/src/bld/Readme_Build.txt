11/2/2006

Sometimes software projects use "Build" or "Make" files to automate the compile and link process.  These are sometimes no more that DOS "Batch" files, and sometimes they are resource files that are used by a �Build� or �Make� utility.

If appropriate, use this directory to store such �Build� and �Make� files.  

(Sometimes, make-files are organized such that each level of subdirectory has its own make-file that refer to the make-files in any deeper levels of subdirectories.  For projects arranged in this way, this folder would not be necessary.)

~Ben Sweet
