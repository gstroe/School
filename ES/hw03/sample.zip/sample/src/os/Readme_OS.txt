11/2/2006

The Operating System (OS) orchestrates the activity of all of the program�s scheduled tasks.  For a simple OS, a periodic timer interrupt can call an OS function (often called a timer �Tick�) that calls the appropriate functions in the appropriate sequence at the appropriate �task� time intervals.

Use this directory to store the OS related files.

~Ben Sweet
