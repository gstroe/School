#ifndef TASK_CFG_H
#define TASK_CFG_H
/**************************************************************************
**
** Module Name:   Task_cfg.h
**
** Module Description:  Periodic Task configuration file.
**
***************************************************************************
**
**  Author:      Benjamin Sweet
**  Revision:    1.0
**  Date:        04-Mar-2012
**
***************************************************************************
** Revision History:
**
** Revision: 1.0    04-Mar-2012   Benjamin Sweet
** * Original version.
**
**************************************************************************/

/*
** Task Configuration Values:
*/

#endif /* TASK_CFG_H */
